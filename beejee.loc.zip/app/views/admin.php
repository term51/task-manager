   <div class="row m-3">
      <div class="col-12 text-center">
         <a href="/" class="link">Вернуться назад</a>
      </div>
   </div>
   <div class="row">
      <div class="offset-md-4 col-md-4 offset-sm-3 col-sm-6">
         <div class="jumbotron">
            <form method="get" action="/" class="admin-login text-center">
               <div class="form-group">
                  <label for="inputLogin">Логин</label>
                  <input type="text" id="inputLogin" class="form-control">
               </div>
               <div class="form-group">
                  <label for="inputPassword">Пароль</label>
                  <input type="password" class="form-control" id="inputPassword">
               </div>
               <button type="submit" class=" btn btn-primary">Войти</button>
            </form>
         </div>
      </div>
   </div>
<?php
